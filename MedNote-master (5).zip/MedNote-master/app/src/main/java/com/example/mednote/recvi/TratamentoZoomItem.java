package com.example.mednote.recvi;

import android.net.Uri;

public class TratamentoZoomItem {

    public Uri Photo;

}
