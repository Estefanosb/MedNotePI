package com.example.mednote.recvi;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TratamentoZoomViewHolder extends RecyclerView.ViewHolder {
    public TratamentoZoomViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
