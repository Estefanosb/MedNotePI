package com.example.mednote.recvi;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SintomaViewHolder extends RecyclerView.ViewHolder {
    public SintomaViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
