package com.example.mednote.recvi;

import android.net.Uri;

public class SintomasItem {
    public Uri photo;
    public String Title;
    public String Desc;
    public String Data;
    public String Hora;
}
