package com.example.mednote.recvi;

import java.util.ArrayList;

public class TratamentoItem {
    public ArrayList<String> Photos;
    public String Title;
    public String Desc;
    public String Data;
    public String Hora;
}
