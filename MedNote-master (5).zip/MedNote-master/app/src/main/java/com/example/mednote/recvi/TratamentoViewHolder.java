package com.example.mednote.recvi;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TratamentoViewHolder extends RecyclerView.ViewHolder {
    public TratamentoViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
